#!/bin/sh
echo lunar-spike-exec
